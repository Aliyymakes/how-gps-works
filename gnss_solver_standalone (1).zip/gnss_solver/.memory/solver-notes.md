# GPS solver notes

## Overview
`mechanism/solver.py` works out a receiver's 3D position from satellite positions and measured distances. It can also work out the receiver's clock error.

## Decisions
- Keep the code readable for a Year 11 student: simple `for` loops, small number of helper functions, clear names, and ordinary-English comments for each maths step.
- Begin at `(0, 0, 0)` with zero clock error and improve the guess using `numpy.linalg.lstsq`.
- Keep clock error as a **distance in metres** while calculating; convert it to seconds when returning it. One second corresponds to 299,792,458 metres at the speed of light.
- Stop when the correction is smaller than 0.001 metres, or after 19 corrections. Together with the starting guess, this gives at most 20 saved steps.
- When `solve_clock=False`, solve for x, y, and z only, with clock error fixed at zero.
- Use plain Python `float`, `bool`, `list`, and `dict` values for the answer so `json.dumps` works.
- Use `position_m` in the returned answer and each step **provisionally**; verify this against the actual `docs/interface.md` before merging.

## Gotchas
- You need four satellites to solve for x, y, z **and** clock error. Three are enough only when clock error is fixed at zero.
- Even a clock error of one microsecond (0.000001 s) changes satellite distances by nearly 300 metres. If the solver ignores it, the position can be very wrong.
- Satellites all pointing in nearly the same direction may not give enough information. The rank check returns an error message if they cannot give a unique answer.
- The repository's `.memory/design.md`, `docs/interface.md`, `mechanism/constants.py`, and PR template were not accessible in the standalone workspace. In particular, check the output key, input format, and existing speed-of-light constant before using this in the real repository.
- Do not import `mechanism.coords` or `mechanism.scenario`; both are out of scope.

## Commands
Run from the project root with NumPy and pytest installed:

```bash
python -m pytest -q
```

Standalone test run: **10 passed**.
